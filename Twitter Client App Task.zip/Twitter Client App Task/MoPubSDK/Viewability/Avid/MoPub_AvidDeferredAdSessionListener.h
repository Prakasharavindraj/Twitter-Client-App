//
//  AvidDeferredAdSessionListener.h
//  AppVerificationLibrary
//
//  Created by Evgeniy Gubin on 22.06.16.
//  Copyright © 2016 Integral. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MoPub_AvidDeferredAdSessionListener <NSObject>

- (void)recordReadyEvent;

@end
