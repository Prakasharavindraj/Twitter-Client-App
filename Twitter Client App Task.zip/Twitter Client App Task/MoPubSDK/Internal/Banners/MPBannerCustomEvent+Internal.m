//
//  MPBannerCustomEvent+Internal.m
//  MoPubSampleApp
//
//  Copyright © 2017 MoPub. All rights reserved.
//

#import "MPBannerCustomEvent+Internal.h"

@implementation MPBannerCustomEvent (Internal)

- (void)trackMPXAndThirdPartyImpressions
{
    // no-op.
}

- (void)startViewabilityTracker
{
    // no-op
}

@end
